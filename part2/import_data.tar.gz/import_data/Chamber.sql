 INSERT INTO Chamber
    (`id`, `name`)
    VALUES
    ('s', 'Senate'),
    ('h', 'House of Representatives');
